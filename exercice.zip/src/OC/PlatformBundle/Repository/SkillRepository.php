<?php
/**
 * Created by PhpStorm.
 * User: Mido
 * Date: 03/12/2016
 * Time: 13:21
 */

namespace OC\PlatformBundle\Repository;


class SkillRepository extends \Doctrine\ORM\EntityRepository
{

} 